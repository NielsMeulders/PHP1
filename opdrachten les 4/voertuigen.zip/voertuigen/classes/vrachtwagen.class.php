<?php

    include_once("voertuig.class.php");

    class vrachtwagen extends voertuig
    {
        private $m_iMaxLast;

    }

?>