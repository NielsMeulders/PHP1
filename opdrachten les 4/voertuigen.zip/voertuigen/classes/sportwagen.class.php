<?php

    include_once("voertuig.class.php");

    class sportwagen extends voertuig
    {
        private $m_bStereoInstallatie;

    }

?>